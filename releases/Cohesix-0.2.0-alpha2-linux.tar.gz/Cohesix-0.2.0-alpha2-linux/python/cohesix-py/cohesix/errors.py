"""Error types for the Cohesix Python client."""

class CohesixError(RuntimeError):
    """Base error for Cohesix client failures."""
